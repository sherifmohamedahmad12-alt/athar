# تطبيق أثر (أندرويد)

1. افتح مجلد Athar في Android Studio (إصدار حديث) وانتظر Gradle Sync.
2. للتجربة: Run على موبايل/محاكي (نسخة debug بإعلانات تجريبية).
3. للنشر: ضع معرّفات AdMob الحقيقية في app/build.gradle.kts داخل بلوك release،
   ثم Build > Generate Signed App Bundle / APK.
4. غيّر applicationId (com.athar.app) لو عايز اسم حزمة خاص بيك قبل أول نشر.
