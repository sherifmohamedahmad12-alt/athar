package com.athar.app

import android.app.Activity
import android.os.SystemClock
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * يعرض إعلانًا بينيًا بعد عدد معيّن من فتح القصص،
 * وبفاصل زمني أدنى حتى لا يزعج القارئ.
 */
class InterstitialManager(private val activity: Activity) {

    companion object {
        private const val STORIES_BETWEEN_ADS = 3          // إعلان كل 3 قصص
        private const val MIN_INTERVAL_MS = 2 * 60 * 1000L // وبفاصل لا يقل عن دقيقتين
    }

    private var ad: InterstitialAd? = null
    private var loading = false
    private var storyOpens = 0
    private var lastShown = SystemClock.elapsedRealtime()

    fun load() {
        if (ad != null || loading) return
        loading = true
        InterstitialAd.load(
            activity,
            BuildConfig.INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(loaded: InterstitialAd) {
                    ad = loaded
                    loading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null
                    loading = false
                }
            }
        )
    }

    fun onPageVisited(url: String?) {
        // صفحة قصة واحدة مثل: /stories/6b06cf...  (وليس قائمة القصص)
        if (url == null || !url.contains("/stories/")) return
        storyOpens++
        val elapsed = SystemClock.elapsedRealtime() - lastShown
        if (storyOpens >= STORIES_BETWEEN_ADS && elapsed >= MIN_INTERVAL_MS) show()
    }

    private fun show() {
        val current = ad
        if (current == null) {
            load()
            return
        }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null
                load()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                ad = null
                load()
            }
        }
        storyOpens = 0
        lastShown = SystemClock.elapsedRealtime()
        ad = null
        current.show(activity)
    }
}
