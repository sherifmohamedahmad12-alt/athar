package com.athar.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var bannerContainer: FrameLayout
    private var adView: AdView? = null
    private lateinit var interstitials: InterstitialManager

    private val siteHost: String = BuildConfig.SITE_URL.toUri().host ?: ""

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* لا شيء */ }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }

        webView = findViewById(R.id.webView)
        progress = findViewById(R.id.progress)
        bannerContainer = findViewById(R.id.bannerContainer)
        interstitials = InterstitialManager(this)

        setupWebView()
        setupBackButton()
        setupAds()
        askNotificationPermission()
        DailyReminderWorker.schedule(this)

        if (savedInstanceState == null) {
            webView.loadUrl(BuildConfig.SITE_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = true
            userAgentString = "$userAgentString AtharApp/1.0"
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                val isWeb = uri.scheme == "http" || uri.scheme == "https"
                if (isWeb && uri.host == siteHost) return false
                // أي رابط خارجي يُفتح في المتصفح أو التطبيق المناسب
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: ActivityNotFoundException) {
                }
                return true
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    view.loadUrl("file:///android_asset/offline.html")
                }
            }

            // يعمل أيضًا مع التنقل داخل الموقع (SPA)
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (!isReload) interstitials.onPageVisited(url)
            }
        }
    }

    private fun setupBackButton() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun setupAds() {
        MobileAds.initialize(this) {}
        interstitials.load()

        val banner = AdView(this)
        banner.adUnitId = BuildConfig.BANNER_ID
        bannerContainer.addView(banner)
        adView = banner

        bannerContainer.post {
            val density = resources.displayMetrics.density
            var widthPx = bannerContainer.width
            if (widthPx == 0) widthPx = resources.displayMetrics.widthPixels
            val adWidth = (widthPx / density).toInt()
            banner.setAdSize(
                AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth)
            )
            banner.loadAd(AdRequest.Builder().build())
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        adView?.pause()
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        adView?.resume()
    }

    override fun onDestroy() {
        adView?.destroy()
        webView.destroy()
        super.onDestroy()
    }
}
